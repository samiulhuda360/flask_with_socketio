import openai
# config.py
OPENAI_API_KEY = "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"

Pexels_API_ENDPOINT = "https://api.pexels.com/v1/search"
Pexels_API_KEY = "cSH3bxfYCoIvez1eS8DrVpqQDJkL0foBxHI6nxOhIW2GJNGBlARIvXeA"